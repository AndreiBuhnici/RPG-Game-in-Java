public interface Potion {
    void usePotion(Character player);
    int getPrice();
    int getRegen();
    int getWeight();
}
