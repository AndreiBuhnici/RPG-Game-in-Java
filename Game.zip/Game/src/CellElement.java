public interface CellElement {
    char toCharacter();
}
