import java.util.ArrayList;

public class Grid extends ArrayList<ArrayList<Cell>> {
    int length;
    int width;
    Character player;
    Cell current_cell;
    private Grid(int length, int width, Character player){
        this.length = length;
        this.width = width;
        this.player = player;
    }

    static Grid grid_gen(int length, int width, Character player){
        Grid grid = new Grid(length,width,player);
        for (int i=0; i<width; i++)
            grid.add(new ArrayList<>(length));

        for (int i=0; i<width; i++){
            for(int j=0; j<length; j++)
                if(i == 0 && j == 0)
                    grid.get(i).add(new Cell(i, j, new Empty(), true));
                else if((i == 0 || i == 1) && j == length - 2) {
                    grid.get(i).add(new Cell(i, j, new Shop(), false));
                }
                else if(i == 2 && j == 0) {
                    grid.get(i).add(new Cell(i, j, new Shop(), false));
                }
                else if(i == length - 2 && j == length - 1) {
                    grid.get(i).add(new Cell(i, j, new Enemy(), false));
                }
                else if(i == length - 1 && j == length - 1) {
                    grid.get(i).add(new Cell(i, j, new Final(), false));
                }
                else {
                    grid.get(i).add(new Cell(i, j, new Empty(), false));
                }
        }
        grid.current_cell = grid.get(0).get(0);
        return grid;
    }

    void goNorth(){
        if((current_cell.x - 1) <0) {
            System.out.println("Can't go North, out of bounds");
            current_cell.wasVisited = true;
        }
        else{
            current_cell = get(current_cell.x - 1).get(current_cell.y);
            player.y -=1;
            if(!current_cell.visited)
                current_cell.visited = true;
            else
                current_cell.wasVisited = true;
        }
    }

    void goSouth(){
        if((current_cell.x + 1) >= width) {
            System.out.println("Can't go South, out of bounds");
            current_cell.wasVisited = true;
        }
        else{
            current_cell = get(current_cell.x + 1).get(current_cell.y);
            player.y +=1;
            if(!current_cell.visited)
                current_cell.visited = true;
            else
                current_cell.wasVisited = true;
        }
    }
    void goWest(){
        if((current_cell.y - 1) < 0) {
            System.out.println("Can't go West, out of bounds");
            current_cell.wasVisited = true;
        }
        else{
            current_cell = get(current_cell.x).get(current_cell.y - 1);
            player.x -=1;
            if(!current_cell.visited)
                current_cell.visited = true;
            else
                current_cell.wasVisited = true;
        }
    }

    void goEast(){
        if((current_cell.y + 1) >= length) {
            System.out.println("Can't go East, out of bounds");
            current_cell.wasVisited = true;
        }
        else{
            current_cell = get(current_cell.x).get(current_cell.y + 1);
            player.x +=1;
            if(!current_cell.visited)
                current_cell.visited = true;
            else
                current_cell.wasVisited = true;
        }
    }
}
