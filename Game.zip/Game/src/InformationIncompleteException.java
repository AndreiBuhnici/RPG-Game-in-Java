public class InformationIncompleteException extends Exception{
    public InformationIncompleteException(String message) {
        super(message);
    }
}
