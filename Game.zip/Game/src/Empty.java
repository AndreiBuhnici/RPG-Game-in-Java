public class Empty implements CellElement{
    @Override
    public char toCharacter() {
        return 'N';
    }
}
