public class Final implements CellElement{
    @Override
    public char toCharacter() {
        return 'F';
    }
}
